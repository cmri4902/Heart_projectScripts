# HEART Priority 2 — LNPDB / Ugi-4CR Integration Feasibility

Generated (UTC): 2026-11-18T20:09:57.648732+00:00

## Verified sources

- LNPDB CSV: `/project/yli4/ypan/lipid_library/input/LNPDB.csv`
- LNPDB SHA-256: `c87319241a4beef9291e5dcd82020d74d3a6c4faa2672180ddcfbbb639f2f6c4`
- Priority-1 identity index: `/project/yli4/ypan/audits/ugi_priority1_interactive_evidence/cache/ugi_priority1_identity.sqlite3`
- Priority-1 scope: **FULL** (15,182,715 records)

## Full LNPDB molecular audit

- Raw LNPDB rows: **19,797**
- Unique neutral, canonical isomeric IL molecules: **12,835**
- Invalid raw IL SMILES rows: **0**; missing IL SMILES rows: **0**
- Ugi-like core by substructure screen: **976** (not proof of Ugi-4CR synthesis)
- Other structures: **11,859**
- Structures with >256 heavy atoms: **5**

## Exact overlap with the completed Ugi identity index

- Exact BLAKE2b-128 canonical identity matches: **0**
- Canonical identities absent from the Ugi index: **12,835**
- Matched in Ugi train: **0**; Ugi validation: **0**; both: **0**
- ugi_like_matched: **0**
- ugi_like_novel: **976**
- non_ugi_like_matched: **0**
- non_ugi_like_novel: **11,859**

## Structural feasibility, separate from synthesis provenance

- The Ugi-like designation is a broad substructure screen only; it neither proves reaction provenance nor confirms availability of the four required reagents.
- Molecules absent from the Ugi index may still overlap with the General pretrained dataset. This report does not resolve General/LNPDB overlap.
- Neutral and protonated representations were tracked separately; they were not silently merged into a different molecular identity.

## Stratified 3D-input compatibility pilot

- Pilot structures: **40**; molecules with usable 3D payload: **10**; skipped/failed: **30**.
- Requested conformers per pilot molecule: 2; heavy atom pilot limit: 256.
- This only tests representative ETKDG/RDKit input feasibility. Full 10-conformer production LMDB generation and production HEART loader/runtime checks are NOT performed.

## Pretraining integration decision

**Analysis status: ANALYSIS_COMPLETE_INTEGRATION_NOT_STARTED**

Recommended integration plan (not executed):
1. Preserve the original 15M Ugi LMDB and the General dataset unchanged.
2. Hold out a documented external LNPDB evaluation subset before training to avoid an optimistic downstream assessment.
3. Generate 3D conformers for the remaining eligible, novel LNPDB structures into a separate, versioned LMDB with Stage-06-compatible valid-slot metadata.
4. Extend the HEART mixed-sampling dataset loader to three named sources (General, Ugi, LNPDB) with explicit source weights and a source-specific validation split.
5. Benchmark matched-steps General+Ugi baseline vs. General+Ugi+LNPDB before claiming any performance benefit.

## Important limitations

- An exact matching negative is not proof of scaffold novelty; the Ugi index contains canonical hashes, not stored pairwise structural similarities.
- Molecular compatibility is not evidence of Ugi-4CR synthetic accessibility or successful RNA delivery.
- LNPDB includes assay/formulation metadata; experimental values are not self-supervised pretraining labels.
- These results are data-integration evidence, not permission to start HEART production training.

## Output files

- `summary.json` — numeric evidence and source fingerprints
- `lnpdb_unique_with_ugi_overlap.csv` — all unique canonical molecules with exact-match membership
- `lnpdb_ugi_matched.csv`, `lnpdb_ugi_novel.csv` — subsets
- `lnpdb_novel_pretraining_candidates.csv` — structural candidates; 3D data pending
- `3d_compatibility_pilot.csv` — measured representative coordinate feasibility
- `figures/` — plots with measured counts, not illustrative charts

## Integration feasibility tiers (proposed, not committed)

- NEW_LNPDB_SOURCE_3D_PENDING: **11,571** unique molecules
- EVALUATION_HOLDOUT_PROPOSED: **1,259** unique molecules
- STRUCTURE_QC_REVIEW: **5** unique molecules

### Scientific boundaries
- **Ugi-like structural motif is not sufficient to prove Ugi-4CR reagent compatibility.** Virtual reaction-library extension would require retrosynthetic decomposition and actual reagent mapping.
- **Exact unmatched is not scaffold novelty.** The available Ugi SQLite index contains canonical hashes, not a structure similarity index.
- **General pretraining overlap remains untested.** Pub-linked holdout is a proposal until provenance and General overlap are reviewed.
- **3D pilot is not full-LNPDB LMDB generation.** Full ETKDG/MMFF with 10 conformers, failure-aware Stage-06 sidecar and loader testing remain pending.
- **Recommended technical integration:** keep Ugi virtual library immutable; create a separately versioned LNPDB LMDB and use controlled General + Ugi + LNPDB sampling.
- Exclude known exact matched Ugi molecules from the incremental LNPDB training source. Protect Ugi validation molecules, and compare against the unchanged General+Ugi baseline.
- **Sampling scenarios** are exposure illustrations, not prescribed optimal weights; compare multiple source weights on the same downstream dataset.

### Additional evidence files
- `lnpdb_complete_integration_assessment.csv`
- `lnpdb_train_source_proposal_3d_pending.csv`
- `lnpdb_publication_holdout_proposal.csv`
- `lnpdb_ugi_like_novel_reagent_review.csv`
- `sampling_exposure_scenarios.csv`
- `fingerprint_pca_lnpdb_only.csv` (if PCA available)
