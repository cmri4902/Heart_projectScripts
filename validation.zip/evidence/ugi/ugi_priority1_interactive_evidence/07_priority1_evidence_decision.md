# HEART Ugi-4CR | Priority 1 evidence decision
**Data gate: REVIEW** | **Production gate: PENDING_RUNTIME_VERIFICATION**
Generated UTC: 2026-11-17T23:44:33.647511+00:00

## Actual measurement summary
- Expected / audited: 15182715 / 15182715 records
- Unique canonical molecules: 15182715
- Duplicate excess: 0
- Train/valid shared molecules: 0
- 3D sidecar indexed records: 15182715
- Real LMDB payload probes: 3500 | errors: 0

## Positive evidence
- All 15,182,715 metadata records in 3,049 shards audited
- Zero noncontiguous_keys across full metadata scan
- Zero bad_3d_count across full metadata scan
- Zero sidecar_disagreement across full metadata scan
- Zero invalid_smiles across full metadata scan
- Zero fragmented_smiles across full metadata scan
- Zero canonical molecular overlap between train and validation
- Stage-06 successful-3D sidecar index exists, has valid range, and covers all declared records
- 3,500 actual LMDB sampled payloads passed structural/coordinate checks

## Confirmed blockers
- None

## Still unknown
- None

## Review before production
- Historical Stage-05 QC marked FAIL; confirm its precise cause and documented Stage-06 resolution (do not overwrite history)

## Production-only review
- Production loader/dry-run has not been dynamically verified on this dataset

## Context / limitations
- Whole-shard train/valid split is not reagent-holdout or scaffold-holdout; interpret ID validation accordingly

## Saved figures
- 01_full_3d_success_histogram.png
- 02_metadata_3d_success.png
- 03_heavy_atom_distribution.png
- 04_identity_overlap_counts.png
- 05_full_audit_anomalies.png
- 05b_train_valid_3d_distribution.png
- 05c_train_valid_heavy_atoms.png
- 06_real_LMDB_molecular_conformer.png
- PILOT_metadata_3d_success.png
- PILOT_or_PARTIAL_progress.png

## Interpretation
Stage-06 safe 3D-prefix policy must be enforced by the actual training loader; a valid sidecar is necessary but not sufficient.
Stage-05 historical status is not rewritten. No automatic dataset modification or training submission.
