#!/bin/bash
#SBATCH --job-name=heart-ugi-p1
#SBATCH --partition=medium
#SBATCH --cpus-per-task=8
#SBATCH --mem=32G
#SBATCH --time=12:00:00
#SBATCH --output=/mnt/home/ypan/heart_liver/model_train/validation/logs/heart-ugi-p1-%j.out
#SBATCH --error=/mnt/home/ypan/heart_liver/model_train/validation/logs/heart-ugi-p1-%j.err

cd /mnt/home/ypan/heart_liver/model_train
python -m jupyter nbconvert --to notebook --execute   validation/notebooks/ugi/HEART_Ugi_Priority1_AutoFull_EN.ipynb   --output validation/notebooks/ugi/HEART_Ugi_Priority1_AutoFull_Executed.ipynb   --ExecutePreprocessor.timeout=-1
